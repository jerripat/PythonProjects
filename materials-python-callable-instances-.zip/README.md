# Python's .__call__() Method: Creating Callable Instances

This folder provides the code examples for the Real Python tutorial [Python's .__call__() Method: Creating Callable Instances](https://realpython.com/python-callable-instances/).